import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.*;

public class Test extends JFrame {
	JPanel contentPane = new JPanel();
	JButton bluethooth = new JButton();
	JButton wifi = new JButton();
	
	JPanel wifiButton = new JPanel();
	JPanel bluethoothButton = new JPanel();

public Test()
{
	this.setSize(400,400);
	contentPane=(JPanel)this.getContentPane();
	JPanel devicePanel = new JPanel();
	devicePanel.setLayout(new BoxLayout(devicePanel, BoxLayout.Y_AXIS));
	bluethooth.setText("Bluethooth");
	bluethoothButton.add(bluethooth);
	devicePanel.add(bluethoothButton);
	wifi.setText("wifi");
//	wifiButton.add(wifi);
	devicePanel.add(wifi);
	devicePanel.add(Box.createRigidArea(new Dimension(0,5)));
	contentPane.add(devicePanel, BorderLayout.CENTER);
}

public static void main(String[] args) {
    Test c =new Test();
    c.setVisible(true);
}
}