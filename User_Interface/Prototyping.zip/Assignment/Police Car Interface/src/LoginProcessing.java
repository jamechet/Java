import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 * Validating ID card with loading frame
 * @author vonry003
 *
 */
public class LoginProcessing extends JDialog implements ActionListener{

	private BorderLayout contentLayout= new BorderLayout();
	private JPanel contentPane= new JPanel();
	JLabel title = new JLabel();
	JLabel picture = new JLabel();
	ImageIcon loadings = new ImageIcon();
	/**
	 * Set title
	 * Set loading picture
	 * @param owner
	 */
	public LoginProcessing(Frame owner){
		super(owner);
		this.setTitle("Loading");
		this.setSize(new Dimension(400, 200));
		contentPane = (JPanel)this.getContentPane();
		contentPane.setLayout(contentLayout);
		title.setText("Validating ID Card");
		title.setFont (title.getFont ().deriveFont (64.0f));
		title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		loadings=new ImageIcon(PoliceCarFrame.class.getResource("loading.gif"));
		
		contentPane.add(title, BorderLayout.NORTH);
		picture.setIcon(loadings);
		contentPane.add(picture, BorderLayout.CENTER);
		pack();
		
		
	}
	public void actionPerformed(ActionEvent arg0) {
		dispose();
		
	}
//	public static void main(String arg[]){
//		LoginProcessing c = new LoginProcessing(new Frame());
//		c.show();
//	}

}
