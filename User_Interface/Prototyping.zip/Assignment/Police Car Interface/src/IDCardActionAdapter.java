import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class IDCardActionAdapter implements ActionListener {
	PoliceCarFrame adaptee;
	public IDCardActionAdapter(PoliceCarFrame adaptee){
		this.adaptee = adaptee;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
			adaptee.idCardActionPerformed(e);

		
	}

}
