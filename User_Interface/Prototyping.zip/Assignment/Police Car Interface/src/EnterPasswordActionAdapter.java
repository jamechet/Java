import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class EnterPasswordActionAdapter implements ActionListener {
	EnterPassword adaptee;
	public EnterPasswordActionAdapter(EnterPassword adaptee){
		this.adaptee = adaptee;
	}
	public void actionPerformed(ActionEvent e) {
			adaptee.confirmPerformed(e);

		
	}


}
