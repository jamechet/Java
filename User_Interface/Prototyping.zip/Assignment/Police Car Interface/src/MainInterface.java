import javax.swing.UIManager;


public class MainInterface {
	public MainInterface(){
		MainInterfaceFrame frame = new MainInterfaceFrame();
		frame.validate();
		frame.setVisible(true);
	
	}
	public static void main(String arg[]){
		// asking question about look and feel
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch(Exception e){
			e.printStackTrace();
		}
		/** new TextEditor() and the code below has the same equivalent ;
		 * without instance variable editor the window frame will not appear.
		 */
		MainInterface screen= new MainInterface();
		

	}
		
	
	

}
