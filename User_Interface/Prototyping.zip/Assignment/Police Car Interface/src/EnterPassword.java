import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.Timer;


public class EnterPassword extends JDialog implements ActionListener {
	JLabel incorrectMessage = new JLabel();
	JButton confirm = new JButton();
	JPanel contentPane = new JPanel();
	BorderLayout contetLayout = new BorderLayout();
	JLabel title = new JLabel();
	JPasswordField pwd = new JPasswordField(10); 
	final SuccessfulLogin imp= new SuccessfulLogin(new IdcardScanning());
	public EnterPassword(Frame owner){
		super(owner);
		this.setTitle("Password");
		this.setSize(new Dimension(400, 400));
		contentPane = (JPanel)this.getContentPane();
		contentPane.setLayout(contetLayout);
		title.setText("Enter Passowrd");
		title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		title.setFont (title.getFont ().deriveFont (64.0f));
		contentPane.add(title, BorderLayout.NORTH);
		pwd.setFont(pwd.getFont ().deriveFont (64.0f));
		pwd.setSize(300, 300);
		contentPane.add(pwd, BorderLayout.CENTER);
		confirm.setText("Confirm");
		
		contentPane.add(confirm, BorderLayout.EAST);
		confirm.addActionListener(new EnterPasswordActionAdapter(this));
		pack();
	}
	public void confirmPerformed(ActionEvent e){
		if(new String(pwd.getPassword()).equals("123")){
			dispose();
			imp.setModal(true);
			imp.setLocationRelativeTo(this);
			imp.show();
			
	
		}
		else{
			incorrectMessage.setText("Inccorect Password please try again");
			incorrectMessage.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
			incorrectMessage.setFont (title.getFont ().deriveFont (30.0f));
			contentPane.add(incorrectMessage, BorderLayout.SOUTH);
			pack();
		}
	}
	public void actionPerformed(ActionEvent arg0) {
		imp.dispose();
		
	}
	

}
