import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Adapter implements ActionListener{

	 SuccessfulLogin adaptee;
	 public Adapter(SuccessfulLogin adaptee){
		 this.adaptee = adaptee;
		 
	 }
	public void actionPerformed(ActionEvent e) {
		adaptee.actionPerformed(e);
	}

}
