import java.awt.*;
import java.awt.Event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class PoliceCarFrame extends JFrame{
	int close=1;
	private JPanel contentPaneMain = new JPanel();
	private JPanel contentPaneWelcome= new JPanel();
	private JPanel contentPanelogo = new JPanel();
	private JPanel contentPanetop = new JPanel();
	private JPanel contentPanebottom = new JPanel();
	private JPanel contentPaneIDcard = new JPanel();
	private JPanel contentPaneFingerPrint = new JPanel();
	private FlowLayout buttonLayout = new FlowLayout();
	
	private ImageIcon picture[] = new ImageIcon[2];
	
	private BorderLayout borderLayout = new BorderLayout();
	
	private JLabel welcome= new JLabel();
	private JLabel slidePicture = new JLabel();

	private JLabel logoVic= new JLabel();
	private JLabel logoSa= new JLabel();
	private JLabel logoNSW = new JLabel();
	private JLabel logoQLD = new JLabel();
	private JLabel logoWTA = new JLabel();
	private JLabel options = new JLabel();
	private ImageIcon iconVic = new ImageIcon();
	private ImageIcon iconSa= new ImageIcon();
	private ImageIcon iconNSW= new ImageIcon();
	private ImageIcon iconQLD= new ImageIcon();
	private ImageIcon iconWTA= new ImageIcon();
	
	private JButton idCard = new JButton();
	private JButton fingerPrint = new JButton();
	/******************************************************************/
	/**
	 * 
	 */
	public PoliceCarFrame(){
		welcomeFrame();


	


		 
	}
	public void welcomeFrame(){
		this.setSize(new Dimension(Toolkit.getDefaultToolkit().getScreenSize()));
		this.setTitle("Police Car");
		/*************************************************************************************************/
		/* Welcome interface */
		
	//	contentPaneWelcome = (JPanel)this.getContentPane();
	//	contentPaneWelcome.setLayout(borderLayout);
		contentPaneMain = (JPanel)this.getContentPane();
		contentPaneMain.setLayout(borderLayout);
		
	
		welcome.setText("Welcome to Driverless Police Car");
		welcome.setFont (welcome.getFont ().deriveFont (64.0f));
		welcome.setFont(new Font("Arial", Font.ITALIC, 100));
		welcome.setForeground(Color.white);
		welcome.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		contentPaneWelcome.add(welcome, BorderLayout.NORTH);
	
		/*************************************************************************************************/
		iconVic= new ImageIcon(PoliceCarFrame.class.getResource("VIC.png"));
		logoVic.setIcon(iconVic);
		contentPanelogo.add(logoVic);
		
		iconSa= new ImageIcon(PoliceCarFrame.class.getResource("SA.jpg"));
		logoSa.setIcon(iconSa);	
		contentPanelogo.add(logoSa);
		
		iconNSW= new ImageIcon(PoliceCarFrame.class.getResource("NSW.gif"));
		logoNSW.setIcon(iconNSW);	
		contentPanelogo.add(logoNSW);
		
		iconQLD= new ImageIcon(PoliceCarFrame.class.getResource("QLD.jpg"));
		logoQLD.setIcon(iconQLD);	
		contentPanelogo.add(logoQLD);
		
		iconWTA= new ImageIcon(PoliceCarFrame.class.getResource("WA.jpg"));
		logoWTA.setIcon(iconWTA);	
		contentPanelogo.add(logoWTA);
		contentPanelogo.setBackground(Color.white);
		contentPaneWelcome.setBackground(Color.blue);
		contentPaneMain.add(contentPaneWelcome, BorderLayout.NORTH);
		contentPaneMain.add(contentPanelogo, BorderLayout.CENTER);
		
		options.setText("Select login options:");
		options.setForeground(Color.blue);
		options.setFont (welcome.getFont ().deriveFont (64.0f));
		options.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
	//	idCard.setText("ID Card");
		idCard.setIcon(new ImageIcon(PoliceCarFrame.class.getResource("idcard1.png")));
	//	idCard.setFont (welcome.getFont ().deriveFont (64.0f));
		idCard.addActionListener(new IDCardActionAdapter(this));
	//	contentPaneIDcard.setLayout(buttonLayout);
		idCard.setPreferredSize(new Dimension(225,150));
		contentPaneIDcard.setBackground(Color.yellow);
		contentPaneIDcard.add(idCard);
		
		//fingerPrint.setText("Fingerprint");
		fingerPrint.setIcon(new ImageIcon(PoliceCarFrame.class.getResource("finger1.png")));
		fingerPrint.setPreferredSize(new Dimension(225,150));
	//	fingerPrint.setFont (welcome.getFont ().deriveFont (64.0f));
		contentPaneFingerPrint.setLayout(buttonLayout);
		contentPaneFingerPrint.add(fingerPrint);
		contentPaneFingerPrint.setBackground(Color.yellow);
		
		contentPanebottom.setLayout(new GridLayout(4,0));
		contentPanebottom.add(options);
		contentPanebottom.add(contentPaneIDcard);
		contentPanebottom.add(contentPaneFingerPrint);
		contentPanebottom.setBackground(Color.yellow);
		contentPaneMain.add(contentPanebottom, BorderLayout.SOUTH);
	}
	/**
	 * 
	 * @param e
	 */
	public void idCardActionPerformed(ActionEvent e){
		//close the current frame
		dispose();
		
		// loading a new idFrame
	//	final IdcardScanning idFrame = new IdcardScanning();
	//	idFrame.setVisible(true);
		final IdcardScanning c = new IdcardScanning();
		
		c.setVisible(true);
		final LoginProcessing dialog = new LoginProcessing(c);
		final EnterPassword dialogPass = new EnterPassword(c);
		//This action listener is to load the dialog
		   ActionListener l = new ActionListener(){
				public void actionPerformed(ActionEvent arg0) {
					
					dialog.setModal(true);					
					dialog.setLocationRelativeTo(c);
				
					dialog.show();		  
				}	    	
			    };
		// By the time is set for assumption that ID card has been scanning, loading new Dialog with login processing	    
		  Timer time= new Timer(5000, l);
		
		    time.setRepeats(false);
		   
		    time.start();
		    // This listener is to close the dialog 
		    ActionListener i = new ActionListener(){
				public void actionPerformed(ActionEvent arg0) {	
					 dialog.dispose();
					 dialogPass.setModal(true);
					 dialogPass.setLocationRelativeTo(c);
					 dialogPass.show();
					 
				}
					    	
			    };
		// By the time is set for assumption that ID card is valid, close the current dialog and open up a new dialog for promt the password
		Timer time1= new Timer(10000, i);
		time1.setRepeats(false);		   
		time1.start();		
		
		ActionListener ii = new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {	
				c.dispose();
				MainInterfaceFrame frame = new MainInterfaceFrame();
				frame.validate();
				frame.setVisible(true);
				 
			}
				    	
		    };
		Timer time2= new Timer(20000, ii);
		time2.setRepeats(false);		   
		time2.start();
		
	}

	
}
