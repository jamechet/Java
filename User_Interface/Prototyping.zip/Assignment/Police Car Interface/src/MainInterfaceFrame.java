import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JMenuItem;
import javax.swing.JSlider;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;

public class MainInterfaceFrame extends JFrame{
	//JPanel Frame
	JPanel mainFrame = new JPanel();
	JPanel northFrame = new Background();
	JPanel centerFrame = new JPanel();
	JPanel eastFrame = new JPanel();
	JPanel westFrame = new JPanel();
	JPanel southFrame = new Background();
	JPanel insideCenter = new JPanel();
	
	JPanel goHomeButton = new JPanel();
	JPanel addressButton = new JPanel();
	JPanel pointOfInterestButton = new JPanel();
	JPanel recentlyFoundButton = new JPanel();
	JPanel parkingButton = new JPanel();
	JPanel coordinateButton = new JPanel();
	
	
	GridBagConstraints c = new GridBagConstraints();
	JLabel j = new JLabel();
	JPanel cc = new JPanel();
	JPanel buttonRadio= new Background();
	JPanel callButton= new Background();
	JPanel buttonGps = new Background();
	JPanel buttonEmergency= new Background();
	JPanel buttonManualMode = new Background();
	JPanel buttonMaintenance = new Background();
	JPanel buttonConfiguration = new Background();
	JPanel buttonService = new Background();
	JPanel buttonCamera= new Background();
	JPanel buttonExternalDevice = new Background();
	JPanel buttonTemperature =  new Background();
	JPanel buttonNorthside = new Background();
	//Jlabel
	JLabel speed = new JLabel();
	JLabel weather = new JLabel();
	JLabel south= new JLabel();
	JLabel gpsAction = new JLabel();
	
	//JButto
	JButton gps= new JButton();
	JButton manualMode = new JButton();
	JButton maintenance = new JButton();
	JButton configuration = new JButton();
	JButton service = new JButton();
	JButton camera= new JButton();
	JButton device= new JButton();
	JButton northside = new JButton();
	JButton call = new JButton();
	JButton radio= new JButton();
	
	JButton goHome = new JButton();
	JButton address = new JButton();
	JButton pointOfInterest = new JButton();
	JButton recentlyFound = new JButton();
	JButton parking = new JButton();
	JButton coordinate = new JButton();
	// Image
	ImageIcon speedPicture = new ImageIcon(MainInterfaceFrame.class.getResource("north.png"));
	ImageIcon map = new ImageIcon(MainInterfaceFrame.class.getResource("gps.png"));
	ImageIcon cammeraPicture = new ImageIcon(MainInterfaceFrame.class.getResource("camera.png"));
	ImageIcon devicePicture = new ImageIcon(MainInterfaceFrame.class.getResource("device.png"));
	ImageIcon maintenancPicture = new ImageIcon(MainInterfaceFrame.class.getResource("maintenanc.png"));
	ImageIcon configPicture = new ImageIcon(MainInterfaceFrame.class.getResource("configuration.png"));
	ImageIcon servicePicture = new ImageIcon(MainInterfaceFrame.class.getResource("service.png"));
	ImageIcon southPicture = new ImageIcon(MainInterfaceFrame.class.getResource("southPart.png"));
	ImageIcon gpsMap = new ImageIcon(MainInterfaceFrame.class.getResource("defaultMap.png"));
//	Image background = Toolkit.getDefaultToolkit().createImage("camera.png");
	
	
	JMenu emergency = new JMenu();
	JMenuItem pullOver = new JMenuItem();
	JMenuItem dataWarning= new JMenuItem();
	JMenuBar menu = new JMenuBar();
	private Icon cameraPicture;
	JMenuBar menuService = new JMenuBar();
	JMenu services = new JMenu();
	JMenuItem nextService = new JMenuItem();
	JMenuItem serviceHistory = new JMenuItem();
	@SuppressWarnings("null")
	public MainInterfaceFrame(){
		 this.setLayout(new BorderLayout( ));
		 this.setSize(new Dimension(Toolkit.getDefaultToolkit().getScreenSize()));
		 mainFrame = (JPanel)this.getContentPane();
		 mainFrame.setLayout(new BorderLayout());
		
		 mainFrame.add(northFrame, BorderLayout.NORTH);
		 mainFrame.add(eastFrame, BorderLayout.EAST);
		 mainFrame.add(westFrame, BorderLayout.WEST);
		 mainFrame.add(southFrame, BorderLayout.SOUTH);
//		 mainFrame.add(centerFrame, BorderLayout.CENTER);
	/*************************NORTH FRAME**************************************************/	 

		northside.setIcon(speedPicture);
	
		northside.setOpaque(false);
		northside.setContentAreaFilled(false);
		northside.setBorderPainted(false);
		buttonNorthside.add(northside);
		
		 northFrame.add(buttonNorthside);
		
	/*************************WEST FRAME**************************************************/			 
		 westFrame.setLayout(new GridLayout(5,0));
		 //Manual driving button	
		 manualMode.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("steering.png")));
		 manualMode.addActionListener(new AdapterManual(this));
		 manualMode.setPreferredSize(new Dimension(100,100));
		 buttonManualMode.add(manualMode);
		 westFrame.add(buttonManualMode);
		
		 // GPS button
		 gps.setIcon(map);
		 gps.setPreferredSize(new Dimension(100,100));
		 gps.addActionListener(new GpsActionAdapter(this));
		 buttonGps.add(gps);
		 

		 westFrame.add(buttonGps);
		 // Camera button
		 camera.setIcon(cammeraPicture);;
		 camera.setPreferredSize(new Dimension(100,100));
		 camera.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
						cc.setVisible(false);
						centerFrame.removeAll();
						gpsAction.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("cameraDone.png")));
						centerFrame.add(gpsAction);
						centerFrame.repaint();
						centerFrame.setVisible(true);
				
				}
			});
		 
		 buttonCamera.add(camera);
		 westFrame.add(buttonCamera);
		 // External device button
		 device.setIcon(devicePicture);
		 device.addActionListener(new AdapterDevice(this));
		 device.setPreferredSize(new Dimension(100, 100));
		 buttonExternalDevice.add(device);
		 westFrame.add(buttonExternalDevice);
		 //call button
		 call.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("call.png")));
		 call.addActionListener(new AdapterCall());
		 call.setPreferredSize(new Dimension(100, 100));
		 callButton.add(call);
		 westFrame.add(callButton);
	
	/*************************EAST FRAME**************************************************/			 
		 eastFrame.setLayout(new GridLayout(5,0));
		 //Emergency button
		 emergency.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("emergency.png")));
		 emergency.setPreferredSize(new Dimension(100, 100));
		 pullOver.setText("Pull over");
		 pullOver.addActionListener(new AdapterPullover(this));
		 dataWarning.setText("Data Warning");
		 emergency.add(pullOver);
		 emergency.add(dataWarning);
		 menu.add(emergency);
		 buttonEmergency.add(menu);
		 eastFrame.add(buttonEmergency);
		 // maintenance button
		 maintenance.setIcon(maintenancPicture);
		 maintenance.setPreferredSize(new Dimension(100, 100));
		 maintenance.addActionListener(new MaintanenceAdapter(this));
		 buttonMaintenance.add(maintenance);
		 eastFrame.add(buttonMaintenance);
		 // configuration button
		 configuration.setIcon(configPicture);
		 configuration.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
						cc.setVisible(false);
						centerFrame.removeAll();
						gpsAction.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("confg.png")));
						centerFrame.add(gpsAction);
						centerFrame.repaint();
						centerFrame.setVisible(true);
				
				}
			});
		 configuration.setPreferredSize(new Dimension(100, 100));
		 buttonConfiguration.add(configuration);
		 eastFrame.add(buttonConfiguration);
		 // service reminder
		 services.setIcon(servicePicture);
		 services.setPreferredSize(new Dimension(100, 100));
		 nextService.setText("Next Service");
		 nextService.addActionListener(new NextServiceAdapter(this));
		 serviceHistory.setText("Service History");
		 serviceHistory.addActionListener(new HistoryServiceAdapter(this));
		 services.add(nextService);
		 services.add(serviceHistory);
		 menuService.add(services);
		 buttonService.add(menuService);
		 eastFrame.add(buttonService);
		 // Radio button
		 radio.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("radio.png")));
		 radio.setPreferredSize(new Dimension(100,100));
		 radio.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
						cc.setVisible(false);
						centerFrame.removeAll();
						gpsAction.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("radioFill.png")));
						centerFrame.add(gpsAction, BorderLayout.CENTER);
						centerFrame.repaint();
						centerFrame.setVisible(true);
				
				}
			});
		 buttonRadio.add(radio);
		 eastFrame.add(buttonRadio);
		 
	/*************************South FRAME**************************************************/			 
		 south.setIcon(southPicture);
		 southFrame.add(south);
		
		 gpsAction.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("background.jpg")));
		 gpsAction.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
	//	 gpsAction.setVerticalAlignment(javax.swing.SwingConstants.TOP);
		 centerFrame.setLayout(new BorderLayout());
		 centerFrame.add(gpsAction, BorderLayout.CENTER);	 
		 centerFrame.setBackground(Color.white);
		 mainFrame.add(centerFrame, BorderLayout.CENTER);

		 insideCenter.setLayout(new GridBagLayout());
		insideCenter.setPreferredSize(new Dimension(610, 600));
	
	}
	/*************************Center FRAME**************************************************/	
	public void gpsActionPeformed(ActionEvent e){
		
		centerFrame.setVisible(false);


		
		goHome.setPreferredSize(new Dimension(90,90));
		address.setPreferredSize(new Dimension(90,90));
		pointOfInterest.setPreferredSize(new Dimension(90,90));
		recentlyFound.setPreferredSize(new Dimension(90,90));
		parking.setPreferredSize(new Dimension(90,90));
		coordinate.setPreferredSize(new Dimension(90,90));
		


		goHome.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("goOffice.png")));
		goHomeButton.add(goHome);

		address.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("address.png")));
		addressButton.add(address);
		pointOfInterest.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("interest.png")));
		pointOfInterestButton.add(pointOfInterest);
		recentlyFound.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("recendFound.png")));
		recentlyFoundButton.add(recentlyFound);
		parking.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("parking.png")));
		parkingButton.add(parking);
		coordinate.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("coordinate.png")));
		coordinateButton.add(coordinate);
		
		address.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				j.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("addressfill.png")));
				c.fill = GridBagConstraints.VERTICAL;
				c.weighty = 10; 
				c.gridwidth = 4;
				c.gridx = 0;
				c.gridy = 3;
				insideCenter.add(j, c);
				gpsAction.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("map.png")));
		//		gpsAction.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
			}
		});
		recentlyFound.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				j.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("recentFoundFill.png")));
				c.fill = GridBagConstraints.VERTICAL;
				c.weighty = 10; 
				c.gridwidth = 4;
				c.gridx = 0;
				c.gridy = 3;
				insideCenter.add(j, c);
			}
		});
		parking.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				j.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("carParkFill.png")));
				c.fill = GridBagConstraints.VERTICAL;
				c.weighty = 10; 
				c.gridwidth = 4;
				c.gridx = 0;
				c.gridy = 3;
				insideCenter.add(j, c);
			}
		});
		
		coordinate.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				j.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("coordinateFill.png")));
				c.fill = GridBagConstraints.VERTICAL;
				c.weighty = 10; 
				c.gridwidth = 4;
				c.gridx = 0;
				c.gridy = 3;
				insideCenter.add(j, c);
			}
		});
		pointOfInterest.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				final InterestButton interest = new InterestButton(new Frame());
				interest.setVisible(true);
				interest.food.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e){
						j.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("foodFill.png")));
						c.fill = GridBagConstraints.VERTICAL;
						c.weighty = 10; 
						c.gridwidth = 4;
						c.gridx = 0;
						c.gridy = 3;
						insideCenter.add(j, c);
						interest.dispose();
						
					}
				});
				interest.fuel.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e){
						j.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("fuelFill.png")));
						c.fill = GridBagConstraints.VERTICAL;
						c.weighty = 10; 
						c.gridwidth = 4;
						c.gridx = 0;
						c.gridy = 3;
						insideCenter.add(j, c);
						interest.dispose();
						
					}
				});
				interest.lodging.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e){
						j.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("hotelFill.png")));
						c.fill = GridBagConstraints.VERTICAL;
						c.weighty = 10; 
						c.gridwidth = 4;
						c.gridx = 0;
						c.gridy = 3;
						insideCenter.add(j, c);
						interest.dispose();
						
					}
				});
				interest.shopping.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e){
						j.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("shoppingFill.png")));
						c.fill = GridBagConstraints.VERTICAL;
						c.weighty = 10; 
						c.gridwidth = 4;
						c.gridx = 0;
						c.gridy = 3;
						insideCenter.add(j, c);
						interest.dispose();
						
					}
				});
				interest.bank.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e){
						j.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("bankFill.png")));
						c.fill = GridBagConstraints.VERTICAL;
						c.weighty = 10; 
						c.gridwidth = 4;
						c.gridx = 0;
						c.gridy = 3;
						insideCenter.add(j, c);
						interest.dispose();
						
					}
				}); 
				interest.hospital.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e){
						j.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("hospitalFill.png")));
						c.fill = GridBagConstraints.VERTICAL;
						c.weighty = 10; 
						c.gridwidth = 4;
						c.gridx = 0;
						c.gridy = 3;
						insideCenter.add(j, c);
						interest.dispose();
						
					}
				}); 
			}
			
		});

		
		insideCenter.setBackground(Color.WHITE);
		
		c.fill = GridBagConstraints.HORIZONTAL;
		JLabel c4= new JLabel();
	
		c.gridx = 0;
		c.gridy = 0;
		insideCenter.add(goHome,c);
		
		c.fill = GridBagConstraints.HORIZONTAL;

		c.gridx = 1;
		c.gridy = 0;
		insideCenter.add(addressButton, c);
		
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 0;
		insideCenter.add(pointOfInterestButton, c);
		
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		insideCenter.add(recentlyFoundButton, c);
		
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 1;
		c.gridy = 1;
		insideCenter.add(parkingButton, c);
		
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 2;
		c.gridy = 1;
		insideCenter.add(coordinateButton, c);
		

		j.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("default.png")));
		c.fill = GridBagConstraints.VERTICAL;
		c.weighty = 10; 
		c.gridwidth = 4;
		c.gridx = 0;
		c.gridy = 3;
		insideCenter.add(j, c);
		
		cc.setVisible(false);
		cc.removeAll();
		cc.add(insideCenter);
		cc.repaint();
		cc.setVisible(true);

		
		cc.setBackground(Color.red);
		mainFrame.add(cc, BorderLayout.WEST);
		
		
	
		gpsAction.setIcon(gpsMap);
		gpsAction.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		mainFrame.add(gpsAction, BorderLayout.CENTER);
	//	mainFrame.setBackground(Color.WHITE);
		
		
	}
	public void actionPerformedFood(ActionEvent e){
		j.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("default.png")));
		c.fill = GridBagConstraints.VERTICAL;
		c.weighty = 10; 
		c.gridwidth = 4;
		c.gridx = 0;
		c.gridy = 3;
		insideCenter.add(j, c);
	}
	public void actionPerformedMaintanence(ActionEvent e){
		cc.removeAll();
	//	cc.repaint();
	//	centerFrame.setVisible(true);
		gpsAction.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("maintenance.png")));
		 centerFrame.add(gpsAction);
		 centerFrame.setVisible(true);
	//	 mainFrame.add(centerFrame, BorderLayout.CENTER);

	}
	public void actionPerformedNextService(ActionEvent e){
		cc.removeAll();
		
		 gpsAction.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("nextService.png")));
	//	 centerFrame.add(gpsAction);	 
		 centerFrame.setVisible(true);
		// mainFrame.add(centerFrame, BorderLayout.CENTER);
	}
	public void actionPerformedServiceHistory(ActionEvent e){
		cc.removeAll();
		
		 gpsAction.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("serviceHistory.png")));
		 centerFrame.setVisible(true); 
	//	 mainFrame.add(centerFrame, BorderLayout.CENTER);
	}
	
	public void actionPerformedDevice(ActionEvent e){
		centerFrame.removeAll();
		centerFrame.repaint();
		centerFrame.setVisible(false);
		cc.setVisible(false);
		centerFrame.setLayout(new BorderLayout());
		centerFrame.setBackground(Color.white);
		
		JPanel buttonBlue = new JPanel();
		buttonBlue.setBackground(Color.white);
		JPanel buttonWifi= new JPanel();
		buttonWifi.setBackground(Color.white);
		JPanel buttonUsb= new JPanel();
		buttonUsb.setBackground(Color.white);
		JPanel buttonSdCard = new JPanel();
		buttonSdCard.setBackground(Color.white);
		JPanel buttonVoiceCommand = new JPanel();
		buttonVoiceCommand.setBackground(Color.white);
		
		JButton blue = new JButton();
		JButton wifi = new JButton();
		JButton usb = new JButton();
		JButton sdCard = new JButton();
		JButton voiceCommand = new JButton();
		JPanel devicePanel = new JPanel();
		devicePanel.setLayout(new GridLayout(5,0));
	//	GridBagConstraints d = new GridBagConstraints();
		devicePanel.setPreferredSize(new Dimension(400, 500));
		devicePanel.setBackground(Color.white);
		
		blue.setPreferredSize(new Dimension(90,90));
		wifi.setPreferredSize(new Dimension(90,90));
		usb.setPreferredSize(new Dimension(90,90));
		sdCard.setPreferredSize(new Dimension(90,90));
		voiceCommand.setPreferredSize(new Dimension(90,90));
	//	blue.setText("Bluetooth");
		blue.setIcon((new ImageIcon(MainInterfaceFrame.class.getResource("bluetooth.png"))));
		buttonBlue.add(blue);
		blue.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
			//	centerFrame.removeAll();
				gpsAction.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("bluetoothFill.png")));
				gpsAction.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
				
			//	centerFrame.repaint();
				centerFrame.setVisible(true);
			}
		}); 
		
		wifi.setIcon((new ImageIcon(MainInterfaceFrame.class.getResource("wifi.png"))));
		buttonWifi.add(wifi);
		usb.setIcon((new ImageIcon(MainInterfaceFrame.class.getResource("usb.png"))));
		usb.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
			//	centerFrame.removeAll();
				gpsAction.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("folder.png")));
			//	centerFrame.repaint();
				centerFrame.setVisible(true);
			}
		}); 
		buttonUsb.add(usb);
		sdCard.setIcon((new ImageIcon(MainInterfaceFrame.class.getResource("sdcard.png"))));
		sdCard.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
			//	centerFrame.removeAll();
				gpsAction.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("sd.png")));
			//	centerFrame.repaint();
				centerFrame.setVisible(true);
			}
		}); 
		buttonSdCard.add(sdCard);
		voiceCommand.setIcon((new ImageIcon(MainInterfaceFrame.class.getResource("voice.png"))));
		voiceCommand.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
			//	centerFrame.removeAll();
				gpsAction.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("voiceCommandFill.png")));
			//	centerFrame.repaint();
				centerFrame.add(gpsAction, BorderLayout.CENTER);
			//	centerFrame.repaint();
			//	centerFrame.setVisible(true);
			}
		}); 
		buttonVoiceCommand.add(voiceCommand);
		
		

		devicePanel.add(buttonUsb);
		devicePanel.add(buttonWifi);
		devicePanel.add(buttonBlue);
		devicePanel.add(buttonSdCard);
		devicePanel.add(buttonVoiceCommand);
		devicePanel.setBackground(Color.white);
		cc.removeAll();
		cc.setBackground(Color.white);
		cc.add(devicePanel);
		cc.repaint();
		
		cc.setVisible(true);
		cc.setBackground(Color.white);
		devicePanel.setBackground(Color.white);
		centerFrame.add(cc, BorderLayout.WEST);
		
		centerFrame.setVisible(true);
	//	mainFrame.add(cc, BorderLayout.WEST);
		
	}
	static final int Left = 50;
	static final int centre = 0;
	static final int Right = -50;
	JLabel pane2 = new JLabel();
	JButton accel = new JButton();
	JButton brake = new JButton();
	JPanel contentPane = new Background();
	JPanel buttonPane = new Background();
	FlowLayout ButtonLayout = new FlowLayout();
	public void actionPerformedManual(ActionEvent e){
		centerFrame.setVisible(false);
		centerFrame.removeAll();
		cc.setVisible(false);
		JPanel display = new Background();
		display.setLayout(new BorderLayout());
		JPanel contentPane = new JPanel();
		contentPane.setAlignmentX(Component.CENTER_ALIGNMENT);
		JSlider turnSlider = new JSlider(JSlider.HORIZONTAL);
		turnSlider.setMaximum(50);
		turnSlider.setMinimum(-50);
		turnSlider.setValue(0);
		turnSlider.setMajorTickSpacing(10);
		turnSlider.setPaintTicks(true);
		
		Hashtable<Integer, JLabel> labelTable = 
	            new Hashtable<Integer, JLabel>();
		labelTable.put(new Integer(centre), new JLabel("Centre"));
		labelTable.put(new Integer(Left), new JLabel("Right"));
		labelTable.put(new Integer(Right),new JLabel("Left"));
		turnSlider.setLabelTable(labelTable);
		turnSlider.setAlignmentX(LEFT_ALIGNMENT);
		accel.setText("Accelerate");
		accel.setPreferredSize(new Dimension(200, 100));
		brake.setText("Brake");
		brake.setPreferredSize(new Dimension(200, 100));
		buttonPane.setBorder(BorderFactory.createEmptyBorder(100,100,10,10));
		buttonPane.add(accel);
		buttonPane.add(brake);
		buttonPane.setLayout(ButtonLayout);
		turnSlider.setPreferredSize(new Dimension(500,50));
		turnSlider.setPaintLabels(true);
		  turnSlider.setBorder(
	              BorderFactory.createEmptyBorder(0,0,0,10));
		 display.add(turnSlider, BorderLayout.NORTH);
		 display.add(buttonPane, BorderLayout.CENTER);
		 JLabel leftside= new JLabel();
		  leftside.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("leftCamera.png")));
		  display.add(leftside, BorderLayout.WEST);
		  JLabel rightside = new JLabel();
		  rightside.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("rightCamera.png")));
		  display.add(rightside, BorderLayout.EAST);
		  JLabel backSide = new JLabel();
		  backSide.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("backCamera.png")));
		  backSide.setHorizontalAlignment(centre);
		  display.add(backSide, BorderLayout.SOUTH);
		  centerFrame.add(display);
		  centerFrame.repaint();
		  centerFrame.setVisible(true);
		 mainFrame.add(centerFrame, BorderLayout.CENTER);
	}
	public void actionPerformedPullOver(ActionEvent e){
		final PullOver pull = new PullOver(new Frame());
		pull.setLocationRelativeTo(this);
		pull.setVisible(true);
		ActionListener ii = new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {	
				pull.dispose();
				JLabel j = new JLabel();
				centerFrame.setVisible(false);
				cc.setVisible(false);
				j.setIcon(new ImageIcon(MainInterfaceFrame.class.getResource("carstop.png")));
				mainFrame.add(j, BorderLayout.CENTER);
			
			//	centerFrame.setVisible(false);
			//	centerFrame.removeAll();
			//	centerFrame.add(j);
			//	centerFrame.repaint();
			//	centerFrame.setVisible(true);
			//	mainFrame.add(centerFrame, BorderLayout.CENTER);
			}
				    	
		    };
		Timer time2= new Timer(5100, ii);
		time2.setRepeats(false);		   
		time2.start();
	

	}
	class Background extends JPanel{

	    public void paintComponent (Graphics g)
	    {
	    	Image c = new ImageIcon(MainInterfaceFrame.class.getResource("background.jpg")).getImage();
	    	super.paintComponent(g);
	        g.drawImage(c,0,0,null);
	    }
	    
	};
	class AdapterManual implements ActionListener{

		MainInterfaceFrame adaptee;
		public AdapterManual(MainInterfaceFrame adaptee){
			this.adaptee= adaptee;
		}
		public void actionPerformed(ActionEvent e) {
			adaptee.actionPerformedManual(e);
			
		}
		
	}
	class GpsActionAdapter implements ActionListener{
		MainInterfaceFrame adaptee;
		GpsActionAdapter(MainInterfaceFrame adaptee){
			this.adaptee = adaptee;
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			adaptee.gpsActionPeformed(e);
		}
	};
	class MaintanenceAdapter implements ActionListener{
		MainInterfaceFrame adaptee;
		MaintanenceAdapter(MainInterfaceFrame adaptee){
			this.adaptee = adaptee;
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			adaptee.actionPerformedMaintanence(e);
		}
	};
	class NextServiceAdapter implements ActionListener{
		MainInterfaceFrame adaptee;
		NextServiceAdapter(MainInterfaceFrame adaptee){
			this.adaptee = adaptee;
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			adaptee.actionPerformedNextService(e);
		}
	};
	class HistoryServiceAdapter implements ActionListener{
		MainInterfaceFrame adaptee;
		HistoryServiceAdapter(MainInterfaceFrame adaptee){
			this.adaptee = adaptee;
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			adaptee.actionPerformedServiceHistory(e);
		}
	};
	class AdapterCall implements ActionListener{

		
		public void actionPerformed(ActionEvent e) {
			Call callDialog = new Call(new Frame());
			callDialog.setVisible(true);
			
		}
		
	};
	class AdapterDevice implements ActionListener{

		MainInterfaceFrame adaptee;
		public AdapterDevice(MainInterfaceFrame adaptee){
			this.adaptee= adaptee;
		}
		public void actionPerformed(ActionEvent e) {
			adaptee.actionPerformedDevice(e);
			
		}
		
	};
	class AdapterPullover implements ActionListener{

		MainInterfaceFrame adaptee;
		public AdapterPullover(MainInterfaceFrame adaptee){
			this.adaptee = adaptee;
		}
		public void actionPerformed(ActionEvent e) {
			adaptee.actionPerformedPullOver(e);
			
		}
		
	}

}
