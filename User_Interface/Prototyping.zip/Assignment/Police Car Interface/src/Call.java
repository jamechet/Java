import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class Call extends JDialog implements ActionListener{
	JPanel contenpane = new JPanel();
	JPanel southPanel = new JPanel();
	JPanel buttonFavourite = new JPanel();
	JPanel buttonRecent = new JPanel();
	JPanel buttonContact = new JPanel();
	JPanel buttonCall = new JPanel();
	
	JButton favourite = new JButton();
	JButton recent = new JButton();
	JButton contact = new JButton();
	JButton call = new JButton();
	
	JLabel callPicture = new JLabel();
	public Call(Frame owner){
		super(owner);
		this.setSize(410,580);
		this.setTitle("Call");
		contenpane= (JPanel)this.getContentPane();


	
		contenpane.setLayout(new BorderLayout());
		
		southPanel.setLayout(new GridLayout(1,4));
		favourite.setText("Favourite");
		favourite.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				callPicture.setIcon(new ImageIcon(PoliceCarFrame.class.getResource("favoriteFill.png")));
				
			}
		}); 
		buttonFavourite.add(favourite);
		southPanel.add(buttonFavourite);
		recent.setText("Recents");
		recent.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				callPicture.setIcon(new ImageIcon(PoliceCarFrame.class.getResource("recentFill.png")));
				
			}
		}); 
		buttonRecent.add(recent);
		southPanel.add(buttonRecent);
		contact.setText("Contacts");
		contact.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				callPicture.setIcon(new ImageIcon(PoliceCarFrame.class.getResource("contactSearch.png")));
				
			}
		}); 
		contenpane.add(callPicture, BorderLayout.CENTER);
		buttonContact.add(contact);
		southPanel.add(buttonContact);
		call.setText("Call");
		
		buttonCall.add(call);
		southPanel.add(buttonCall);
		contenpane.add(southPanel, BorderLayout.SOUTH);
		call.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				callPicture.setIcon(new ImageIcon(PoliceCarFrame.class.getResource("keypad.png")));
				
			}
		}); 
		callPicture.setIcon(new ImageIcon(PoliceCarFrame.class.getResource("favoriteFill.png")));
		contenpane.add(callPicture, BorderLayout.CENTER);

		
	}
	public void actionPerformedCall(ActionEvent arg0) {
		
		
	}
	
	public static void main(String arg[]){
		Call c = new Call(new Frame());
		c.validate();
		c.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
