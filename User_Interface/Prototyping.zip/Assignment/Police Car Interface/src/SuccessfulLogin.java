import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.Timer;


public class SuccessfulLogin extends JDialog implements ActionListener {
	JPanel contentPane = new JPanel();
	BorderLayout borderLayout = new BorderLayout();
	JLabel title = new JLabel();
	ImageIcon loadingBar = new ImageIcon();
	JLabel picture = new JLabel();
	
	public SuccessfulLogin(Frame owner){
		super(owner);
	//	this.setUndecorated(true);
		this.setTitle("Loading");
	//	this.setSize(new Dimension(400, 400));
		contentPane=(JPanel)this.getContentPane();
//		contentPane.setSize(400, 400);
		contentPane.setLayout(borderLayout);
		contentPane.setBackground(Color.WHITE);
		title.setText("Successful Login Please wait a moment");
	
		title.setFont (title.getFont ().deriveFont (25.0f));
		title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		contentPane.add(title, BorderLayout.NORTH);
		loadingBar = new ImageIcon(SuccessfulLogin.class.getResource("loading.gif"));
		picture.setIcon(loadingBar);
		
		contentPane.add(picture, BorderLayout.CENTER);
		
		pack();
	
		 ActionListener i = new ActionListener(){
				public void actionPerformed(ActionEvent arg0) {	
					 setVisible(false);
				}
					    	
			    };
		Timer a= new Timer(20000, i);
		a.setRepeats(false);
		a.start();
		

		
		
	}
	public void actionPerformed(ActionEvent e) {
		dispose();
		
	}
	

}
