import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;






import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
/**
 * Introduction how to scan ID card
 * @author vonry003
 *
 */
public class IdcardScanning extends JFrame {
	JLabel titles = new JLabel();
	ImageIcon picture= new ImageIcon();
	JLabel box = new JLabel();
	JLabel title= new JLabel();
	 ImageIcon loading= new ImageIcon();
	 JPanel center = new JPanel();
	 JPanel contentPaintMain = new JPanel();
	 Timer time;
	 /**
	  * Set title and picture slide
	  */
	public IdcardScanning(){
	    this.setLayout(new BorderLayout( ));
	    this.setSize(new Dimension(Toolkit.getDefaultToolkit().getScreenSize()));
	    contentPaintMain = (JPanel)this.getContentPane();
	    contentPaintMain.setLayout(new BorderLayout());
	    title.setText("Please Scan Your IDCard");
	    title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		title.setFont(new Font("Arial", Font.ITALIC, 100));
		title.setForeground(Color.blue);
	  
	    picture = new ImageIcon(IdcardScanning.class.getResource("scanID.gif"));
	
	    box.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
	    contentPaintMain.add(title, BorderLayout.NORTH);
	    contentPaintMain.add(box,BorderLayout.CENTER);
	    contentPaintMain.setBackground(Color.white);
	    box.setIcon(picture);
   
	//	pack();
	}

	
	/**
	 * Method actionPerformed ok button will close after clicking
	 */
	public void actionPerformed(ActionEvent e){
			dispose();
	}
	
	

}
