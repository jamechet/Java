import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
public class PoliceCar {
	/**
	 * 
	 */
	public PoliceCar(){
	
		PoliceCarFrame frame = new PoliceCarFrame();
		frame.validate();
		frame.setVisible(true);
		screenSize(frame);
	}	
	/**
	 * 
	 * @param frame
	 */
	public void screenSize(PoliceCarFrame frame){
		// Toolkit class  containing method for resetting size or location of a top level container
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = frame.getSize();
		if (frameSize.height > screenSize.height){
		frameSize.height = screenSize.height;
		}
		if (frameSize.width > screenSize.width){
		frameSize.width = screenSize.width;
		}
		frame.setLocation((screenSize.width
		-
		frameSize.width) / 2,
		(screenSize.height
		-
		frameSize.height) /2 );
	}
	/**
	 * Method Closing window
	 * Using class Window Adapter and void windowCLosing
	 * @return
	 */
	public WindowAdapter  closingWindow(final IdcardScanning frame)  {

		WindowAdapter b = new WindowAdapter(){
			public void windowClosing(WindowEvent e) {		
						System.exit(0);
			}	
		};
		return b;
	}
	/**
	 * 
	 * @param arg
	 */
	public static void main(String arg[]){
		// asking question about look and feel
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch(Exception e){
			e.printStackTrace();
		}
		/** new TextEditor() and the code below has the same equivalent ;
		 * without instance variable editor the window frame will not appear.
		 */
		PoliceCar screen= new PoliceCar();
		

	}

}
