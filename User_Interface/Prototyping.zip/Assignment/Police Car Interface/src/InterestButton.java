import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;


public class InterestButton extends JDialog implements ActionListener {
	private JPanel contentPane = new JPanel();
	JButton food = new JButton();
	JButton	fuel = new JButton();
	JButton lodging = new JButton();
	JButton shopping = new JButton();
	JButton bank = new JButton();
	JButton hospital = new JButton();
	
	JPanel foodButton = new JPanel();
	JPanel fuelButton = new JPanel();
	JPanel lodgingButton = new JPanel();
	JPanel shoppingButton = new JPanel();
	JPanel bankButton = new JPanel();
	JPanel hospitalButton = new JPanel();
	
	
	public InterestButton(Frame owner){
		super(owner);
		this.setTitle("Interest");
		this.setSize(400, 400);
		
		contentPane =(JPanel)this.getContentPane();
		contentPane.setLayout(new GridLayout(2,3));
		
		food.setPreferredSize(new Dimension(100,100));
		fuel.setPreferredSize(new Dimension(100,100));
		lodging.setPreferredSize(new Dimension(100,100));
		shopping.setPreferredSize(new Dimension(100,100));
		bank.setPreferredSize(new Dimension(100,100));
		hospital.setPreferredSize(new Dimension(100,100));
		

		
		food.setIcon(new ImageIcon(PoliceCarFrame.class.getResource("food.png")));
		
		foodButton.add(food);
		
		
		fuel.setIcon(new ImageIcon(PoliceCarFrame.class.getResource("fuel.png")));
		fuelButton.add(fuel);
		lodging.setIcon(new ImageIcon(PoliceCarFrame.class.getResource("lodging.png")));
		lodgingButton.add(lodging);
		shopping.setIcon(new ImageIcon(PoliceCarFrame.class.getResource("shopping.png")));
		shoppingButton.add(shopping);
		bank.setIcon(new ImageIcon(PoliceCarFrame.class.getResource("bank.png")));
		bankButton.add(bank);
		hospital.setIcon(new ImageIcon(PoliceCarFrame.class.getResource("hospital.png")));
		hospitalButton.add(hospital);
		
		contentPane.add(fuelButton);
		contentPane.add(foodButton);
		contentPane.add(lodgingButton);
		contentPane.add(shoppingButton);
		contentPane.add(bankButton);
		contentPane.add(hospitalButton);
	
		
		
	}
	
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	public static void main(String arg[]){
		InterestButton c = new InterestButton(new Frame());
	//	c.validate();
		c.setVisible(true);
	}
}
