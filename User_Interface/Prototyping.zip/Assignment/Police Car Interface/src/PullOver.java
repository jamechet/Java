import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class PullOver extends JDialog implements ActionListener {
	JPanel contentPane = new JPanel();
	JLabel center = new JLabel();
	JLabel south = new JLabel();
	public PullOver(Frame owner){

		this.setSize(400,400);
		this.setTitle("Pull Over");
		contentPane=(JPanel)this.getContentPane();
		contentPane.setLayout(new BorderLayout());
		center.setIcon(new ImageIcon(PullOver.class.getResource("countdown.gif")));
		contentPane.add(center, BorderLayout.CENTER);
		south.setText(" Warning car will be stop in 5 seconds, be prepare ");
		south.setForeground(Color.red);
		south.setFont (south.getFont ().deriveFont (15.0f));
		south.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		contentPane.add(south, BorderLayout.SOUTH);
		pack();
	}
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	public void screenSize(Frame frame){
		// Toolkit class  containing method for resetting size or location of a top level container
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = frame.getSize();
		if (frameSize.height > screenSize.height){
		frameSize.height = screenSize.height;
		}
		if (frameSize.width > screenSize.width){
		frameSize.width = screenSize.width;
		}
		frame.setLocation((screenSize.width
		-
		frameSize.width) / 2,
		(screenSize.height
		-
		frameSize.height) /2 );
	}

}
